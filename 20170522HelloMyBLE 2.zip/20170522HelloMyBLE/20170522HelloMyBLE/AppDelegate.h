//
//  AppDelegate.h
//  20170522HelloMyBLE
//
//  Created by user35 on 2017/5/22.
//  Copyright © 2017年 user35. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

