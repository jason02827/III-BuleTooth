//
//  TalkingViewController.m
//  20170522HelloMyBLE
//
//  Created by user35 on 2017/5/22.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "TalkingViewController.h"

@interface TalkingViewController ()<CBPeripheralDelegate>
@property (weak, nonatomic) IBOutlet UITextField *inputTextField;
@property (weak, nonatomic) IBOutlet UITextView *logTextView;

@end

@implementation TalkingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    CBPeripheral *peripheral = _targetCharacteristic.service.peripheral;
    peripheral.delegate = self;
    [peripheral setNotifyValue:true forCharacteristic:_targetCharacteristic];
}

- (IBAction)sendBtnPressed:(id)sender {

    //Check if inputTextField is empty?
    if (_inputTextField.text.length == 0) {
        return;
    }
    [_inputTextField resignFirstResponder];//Dismiss keyboard
    
    //Send text to peripheral
    NSString *text = [NSString stringWithFormat:@"[----] %@\n", _inputTextField.text];
    NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
    
//    CBCharacteristicProperties characteristicProperties = [_targetCharacteristic properties];
//    CBCharacteristicWriteType type;
//    if (characteristicProperties & CBCharacteristicPropertyWriteWithoutResponse) {
//        
//        type = CBCharacteristicWriteWithoutResponse;
//    } else {
//        
//        type =  CBCharacteristicWriteWithResponse;
//    }
//    
//    [_targetCharacteristic.service.peripheral writeValue:data forCharacteristic:_targetCharacteristic type:type];
//}

    
    CBCharacteristicProperties properties = _targetCharacteristic.properties;
    CBCharacteristicWriteType type;
    
    if (properties & CBCharacteristicPropertyWriteWithoutResponse) {
        type = CBCharacteristicWriteWithoutResponse;
    }else{
        type = CBCharacteristicWriteWithResponse;
    }
    [_targetCharacteristic.service.peripheral writeValue:data forCharacteristic:_targetCharacteristic type:type];
}//CBCharacteristicWriteWithResponse

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - CBPeripheralDelegate Methods

-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    
    NSString *message;
    if (error) {
        message = error.description;
    }else{
        message = [[NSString alloc]initWithData:characteristic.value encoding:NSUTF8StringEncoding];
    }
    _logTextView.text = [NSString stringWithFormat:@"%@, %@", message, _logTextView.text];
}

-(void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error{
    if (error) {
        NSLog(@"didWriteValueForCharacteristic Fail: %@ ",error);
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
