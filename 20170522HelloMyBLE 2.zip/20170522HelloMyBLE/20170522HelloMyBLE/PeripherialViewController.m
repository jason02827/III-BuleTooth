//
//  SecondViewController.m
//  20170522HelloMyBLE
//
//  Created by user35 on 2017/5/22.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "PeripherialViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>

#define SERVICE_UUID            @"8881"
#define CHARACTERISTIC_UUID     @"8882"
#define CHATROOM_NAME           @"zzzzzz Chatroom"

@interface PeripherialViewController ()<CBPeripheralManagerDelegate>
{
    CBPeripheralManager *manager;
    CBMutableCharacteristic *myCharacteristic;
    
    NSMutableString *textWillBeSent;
}
@property (weak, nonatomic) IBOutlet UITextField *inputTextField;
@property (weak, nonatomic) IBOutlet UITextView *logTextView;

@end

@implementation PeripherialViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    manager = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil];
}

- (IBAction)sendBtnPressed:(id)sender {
    
    if (_inputTextField.text.length == 0) {
        return;
    }
    [_inputTextField resignFirstResponder];
    
    NSString *text = [NSString stringWithFormat:@"[%@] %@\n", CHATROOM_NAME, _inputTextField.text];
    
    [self sendText:_inputTextField.text central:nil];
    
    _logTextView.text = [NSString stringWithFormat:@"%@ %@", text,_logTextView.text];
}


- (IBAction)advertiseEnableValueChanged:(id)sender {
    
    if ([sender isOn]) {
        [self startToAdvertise];
    }else{
        [self stopAdvertise];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) startToAdvertise{
    CBUUID *serviceUUID = [CBUUID UUIDWithString:SERVICE_UUID];
    CBUUID *characteristicUUID = [CBUUID UUIDWithString:CHARACTERISTIC_UUID];
    if (myCharacteristic == nil) {
        
        //Prepare characteristic
        CBCharacteristicProperties properties =
        CBCharacteristicPropertyWrite |
        CBCharacteristicPropertyNotify |
        CBCharacteristicPropertyRead;
        CBAttributePermissions permissions =
        CBAttributePermissionsReadable |
        CBAttributePermissionsWriteable;
        
        myCharacteristic = [[CBMutableCharacteristic alloc] initWithType:characteristicUUID properties:properties value:nil permissions:permissions];
        
        //Prepare service
        CBMutableService *service = [[CBMutableService alloc] initWithType:serviceUUID primary:true];
        service.characteristics = @[myCharacteristic];
        [manager addService:service];
    }
    //Start to advertise
    NSArray *serviceUUIDs = @[serviceUUID]; //Important
    NSDictionary *info = @{CBAdvertisementDataLocalNameKey:CHATROOM_NAME,
                           CBAdvertisementDataServiceUUIDsKey:serviceUUIDs};
    [manager startAdvertising:info];
}

-(void) stopAdvertise{
    [manager stopAdvertising];
}

-(void)sendText:(NSString *)text
        central:(CBCentral *)central{
    NSArray *centrals = (central == nil) ? nil : @[central];
    NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
    
    BOOL result = [manager updateValue:data forCharacteristic:myCharacteristic onSubscribedCentrals:centrals];
    NSLog(@"Send Text Result: %@",result? @"OK":@"Fail");
    
    //Put text into textWillBeSent and send it latter if necessary
    if (result == false) {
        
        if (textWillBeSent == nil) {
            textWillBeSent = [NSMutableString stringWithString:text];
        }else{
            [textWillBeSent appendString:text];
        }
    }
}

#pragma mark - CBPeripheralManagerDelegate Methods

-(void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral{
    CBManagerState state = peripheral.state;
    
    if (state != CBManagerStatePoweredOn) {
        NSLog(@"BLE is note ready (%ld)",(long)state);
    }
}

-(void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didSubscribeToCharacteristic:(CBCharacteristic *)characteristic{
    
    NSString *info = [NSString stringWithFormat:@"* Central subscribed, UUID:%@, max update length: %ld\n",central.identifier.UUIDString, (unsigned long)central.maximumUpdateValueLength];
    _logTextView.text = [NSString stringWithFormat:@"%@ %@", info, _logTextView.text];
    
    //Say Hello to the central
    NSString *hello = [NSString stringWithFormat:@"[%@]Welcome.",CHATROOM_NAME];
   
    [self sendText:hello central:central];
    
    //Broadcast to tell all cantrals
    NSString *broadcast = [NSString stringWithFormat:@"* Someone coming..(Total:%u\n", myCharacteristic.subscribedCentrals.count];
    
    [self sendText:broadcast central:nil];
}

-(void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didUnsubscribeFromCharacteristic:(CBCharacteristic *)characteristic{
    
    //Broadcast to tell all cantrals
    NSString *broadcast = [NSString stringWithFormat:@"* Someone leaving..(Total:%u\n", myCharacteristic.subscribedCentrals.count];
    
    [self sendText:broadcast central:nil];
}

-(void) peripheralManagerIsReadyToUpdateSubscribers:(CBPeripheralManager *)peripheral{
    
    NSLog(@"peripheralManagerIsReadyToUpdateSubscribers executed.");
    
    [self sendText:textWillBeSent central:nil];
    textWillBeSent = nil;
}

-(void) peripheralManager:(CBPeripheralManager *)peripheral didReceiveWriteRequests:(NSArray<CBATTRequest *> *)requests{
    
    for (CBATTRequest *tmp in requests) {
        NSString *message = [[NSString alloc]initWithData:tmp.value encoding:NSUTF8StringEncoding];
        
        //Forward to all centrals
        [self sendText:message central:nil];
        _logTextView.text = [NSString stringWithFormat:@"%@ %@", message,_logTextView.text];
        
        //Important
        [manager respondToRequest:tmp
                       withResult:CBATTErrorSuccess];
    }
}

@end








