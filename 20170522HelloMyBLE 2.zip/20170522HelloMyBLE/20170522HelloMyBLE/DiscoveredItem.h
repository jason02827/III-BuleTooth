//
//  DiscoveredItem.h
//  20170522HelloMyBLE
//
//  Created by user35 on 2017/5/22.
//  Copyright © 2017年 user35. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface DiscoveredItem : NSObject

@property (nonatomic,strong) CBPeripheral *peripheral;
@property (nonatomic,assign) NSInteger lastRSSI;
@property (nonatomic,strong) NSDate *lastSeenDate;

@end


