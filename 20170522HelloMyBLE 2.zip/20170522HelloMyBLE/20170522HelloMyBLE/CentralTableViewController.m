//
//  CentralTableViewController.m
//  20170522HelloMyBLE
//
//  Created by user35 on 2017/5/22.
//  Copyright © 2017年 user35. All rights reserved.
//

#import "CentralTableViewController.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import "DiscoveredItem.h"
#import "TalkingViewController.h"

#define TARGET_UUID_PREFIX @"888"
//#define TARGET_UUID_PREFIX @"FFE1"
//#define TARGET_UUID_PREFIX @"DFB1"

@interface CentralTableViewController ()<CBCentralManagerDelegate,CBPeripheralDelegate>
{   CBCentralManager *manager;
    
    NSMutableDictionary *allItems;
    NSDate *lastReloadDate;
    
    NSMutableArray *restServices;
    NSMutableString *infoString;
    
    //For Talking Support.
//    CBPeripheral *talkingPeripheral;
    CBCharacteristic *talkingCharacteristic;
    BOOL isTalkingMode;
}

@end

@implementation CentralTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    manager = [[CBCentralManager alloc]initWithDelegate:self queue:nil];//queue用nil是在主執行緒做事
    
    allItems = [NSMutableDictionary new];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    //Disconnect peripheral when return from Talking VC.
    if (talkingCharacteristic) {
        [manager cancelPeripheralConnection:talkingCharacteristic.service.peripheral];
        talkingCharacteristic = nil;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return allItems.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    NSArray *allKeys = allItems.allKeys;
    NSString *targetKey = allKeys[indexPath.row];
    DiscoveredItem *item = allItems[targetKey];
    
    NSString *line1String = [NSString stringWithFormat:@"%@ RSSI: %ld",item.peripheral.name, (long)item.lastRSSI];
    
    NSString *line2String = [NSString stringWithFormat:@"Last Seen %.1f second ago",[item.lastSeenDate timeIntervalSinceNow]*-1];
    
    cell.textLabel.text = line1String;
    cell.detailTextLabel.text = line2String;
                             
    return cell;
}

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    isTalkingMode = true;
    [self connectWithIndexPath:indexPath];
}

-(void) tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath{
    isTalkingMode = false;
    [self connectWithIndexPath:indexPath];
}

-(void) connectWithIndexPath: (NSIndexPath *) indexPath{
    NSArray *allKeys = allItems.allKeys;
    NSString *targetKey = allKeys[indexPath.row];
    DiscoveredItem *item = allItems[targetKey];
   
    [manager connectPeripheral:item.peripheral options:nil];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"goTalking"]) {
        TalkingViewController *vc = segue.destinationViewController;
        vc.targetCharacteristic = talkingCharacteristic;
    }
}


- (IBAction)scanEnableValueChanged:(id)sender {
    if ([sender isOn]) {
        [self startToScan];
    }else{
        [self stopScanning];
    }
}

-(void)startToScan{
    
//    CBUUID *target1 = [CBUUID UUIDWithString:@"12345678-1234-1234-1234-1234567890AB"];  //指定掃描到的裝置名稱
//    CBUUID *target2 = [CBUUID UUIDWithString:@"1234"];  //指定掃描到的裝置名稱
//    NSArray *services = @[target1,target2];
    
    NSArray *services = @[];
    
    NSDictionary *options = @{CBCentralManagerScanOptionAllowDuplicatesKey:@(true)};
    
    [manager scanForPeripheralsWithServices:services options:options];
    
}

-(void)stopScanning{
    [manager stopScan];
}

-(void) showAlertWithMessage:(NSString *) message{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    
    [alert addAction:ok];
    
    [self presentViewController:alert animated:true completion:nil];
}


#pragma mark - CBCentralManagerDidUpdateState Methods
-(void)centralManagerDidUpdateState:(CBCentralManager *)central{
    CBManagerState state = central.state;
    
    if (state !=CBManagerStatePoweredOn) {
        NSString *message = [NSString stringWithFormat:@"BLE is not available.(%ld)",(long)state];
        [self showAlertWithMessage:message];
        
    }
}

-(void) centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *,id> *)advertisementData RSSI:(NSNumber *)RSSI{

    DiscoveredItem *existItem = allItems[peripheral.identifier.UUIDString];
    
    if (existItem == nil) {
        //Show NSLog only at the first time we found the peripheral
        NSLog(@"Found: %@, RSSI: %ld, Identifier: %@, Data: %@",peripheral.name ,(long)RSSI.integerValue ,peripheral.identifier.UUIDString, advertisementData.description);
    }
    NSDate *now = [NSDate date];
    DiscoveredItem *newItem = [DiscoveredItem new];
    newItem.peripheral = peripheral;
    newItem.lastRSSI = RSSI.integerValue;
    newItem.lastSeenDate = now;
    
    [allItems setObject:newItem forKey:peripheral.identifier.UUIDString];

//Show and Reload Tableview Wisely
    if (existItem == nil || [now timeIntervalSinceDate:lastReloadDate] > 3.0) {
        lastReloadDate = now;
        [self.tableView reloadData];
    }
}

-(void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral{
    
    NSLog(@"Connected to %@",peripheral.name);
    [self stopScanning];
    
    peripheral.delegate = self;
    [peripheral discoverServices:nil];
}

-(void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    NSString *message = [NSString stringWithFormat:@"Fail to connect: %@",error.description];
    [self showAlertWithMessage:message];
}

-(void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error{
    [self startToScan];
}

#pragma mark - CBPeripheralDelegate - Methods

-(void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    
    if (error) {
        NSString *message = [NSString stringWithFormat:@"Fail to discovery services: %@",error.description];
        [self showAlertWithMessage:message];
        
        //Disconnect
        [manager cancelPeripheralConnection:peripheral];
        return;
    }
    restServices = [NSMutableArray arrayWithArray:peripheral.services];
    
    CBService *targerService = peripheral.services.firstObject;
    
    [peripheral discoverCharacteristics:nil forService:targerService];
    //Remove the first one
    [restServices removeObjectAtIndex:0];
    
    infoString = [NSMutableString new];
}

-(void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error{
    if (error) {
        NSString *message = [NSString stringWithFormat:@"Fail to discovery characteristic: %@",error.description];
        [self showAlertWithMessage:message];
        
        //Disconnect
        [manager cancelPeripheralConnection:peripheral];
        return;
    }
    [infoString appendFormat:@"*** Peripheral: %@(Total: %u services)\n",peripheral.name, peripheral.services.count];
    [infoString appendFormat:@"** Service: %@ (Total: %u characteristic)\n",service.UUID.UUIDString, service.characteristics.count];
    
    for (CBCharacteristic *tmp in service.characteristics) {
        [infoString appendFormat:@"* Char.:%@\n",tmp.UUID.UUIDString];
        
        //Cheeck if it is the characteristic that we are looking for
        if ([tmp.UUID.UUIDString hasPrefix:TARGET_UUID_PREFIX] && isTalkingMode) {
//            talkingPeripheral = peripheral;
            talkingCharacteristic =tmp;
            
            [self performSegueWithIdentifier:@"goTalking" sender:nil];
            return;
        }
    }
    //Move to next service?
    if (restServices.count == 0) {
        [self showAlertWithMessage:infoString];
        [manager cancelPeripheralConnection:peripheral];
        return;
    }else{
        //Next Service
        CBService *targerService = peripheral.services.firstObject;
        
        [peripheral discoverCharacteristics:nil forService:targerService];
        //Remove the first one
        [restServices removeObjectAtIndex:0];
    }
}


@end






